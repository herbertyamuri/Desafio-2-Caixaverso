clonar o respositorio com o comando `git clone https://github.com/Suko-dev/aulas-ada.git`

baixar o node no site `https://nodejs.org/pt/download`

conferir a instalação do node com o comando `node -v` (pode ser necessário reiniciar a IDE após instalação)

dar o comando `npm install` na raiz do projeto para instalar dependências

dar o comando `npm run start` para iniciar o projeto; 

as rotas estarão disponibilizadas na url `http://localhost:3000/api`